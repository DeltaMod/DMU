from DMU import utils as dm
from DMU import graph_styles as gstl
from matplotlib import pyplot as plt
from matplotlib import patches as ptc
from matplotlib.transforms import Affine2D
import numpy as np
import os

gstl.graph_style()

fl = dm.Get_FileList('', ext='.dat')[0]['.dat']

data = [dm.Nanonis_dat_read(file,portformat=True) for file in fl]


"""
Note: portformat refers to what is on each of the ports of your measurement tool (so, port 1->port 4) and does not refer to the nanowire locatations on which each goes to. See the data folder structure for more info.

If you set it to false, then you can't use "Nanowire_Diagram_Plotter" but the bias_plotter will still work. 

In Notepad++, you can use "replace in file" to replace your Comment01 \t Comment01 to be just Comment01
In general, it will only look for the first two columns so if you have three (i.e comment01;comment02;actual data) it will not find what you are looking for, so you need to fix that. 

"""


for d in data:
    dat = d['[DATA]']
FIG = []    

for i,d in enumerate(data): 
    FIG.append(dm.ezplot()) 
    filename = fl[i].split('\\')[-1]
    FIG[i].file = filename
    dm.bias_plotter(data[i]['[DATA]'],FIG[i].ax[0],fwd=True,bwd=True,title=filename,c=['b','r'])
    dm.Nanowire_Diagram_Plotter(FIG[i].fig,FIG[i].ax[0], data[i]['[Pre-Data]'])
    
savefig   = False
figformat = ".png" 

dirlist = os.listdir()
if "Figures" not in dirlist:
    os.makedirs('Figures')
    
if savefig == True:
    for fig in FIG:
        fig.fig.savefig("Figures\\"+fig.file.split('.dat')[0]+figformat)
        
"""

Manual Plotting example:
    assuming you want to plot data[1] with data[3], then you can do the following
    
fig  = plt.figure(55)

ax = fig.gca()

dm.bias_plotter(data[1]['[DATA]'],ax,fwd=True,bwd=True,title=filename,c=['b','r'])

dm.bias_plotter(data[3]['[DATA]'],ax,fwd=True,bwd=True,title=filename,c=['c','g'])


"""